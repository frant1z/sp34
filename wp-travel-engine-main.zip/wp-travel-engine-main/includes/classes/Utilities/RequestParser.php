<?php
/**
 * Request Parser.
 *
 * @package WPTravelEngine
 * @since 6.0.0
 */

namespace WPTravelEngine\Utilities;

use WP_REST_Request;

/**
 * Request Parser class.
 */
class RequestParser extends WP_REST_Request {

}
