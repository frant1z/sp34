<?php
/**
 * Caching for wptravelengine
 *
 * @since 5.0.0
 */

class WP_Travel_Engine {

	protected $group = 'wte';

	public function get_data( $key, $group ) {

	}



}
