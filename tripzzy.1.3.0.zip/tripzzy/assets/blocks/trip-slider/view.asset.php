<?php return array('dependencies' => array(), 'version' => '3e400268b7239427854f');
