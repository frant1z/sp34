<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:wptravelenginetripblocks/trip-ratings /-->

<!-- wp:wptravelenginetripblocks/star-ratings /-->

<!-- wp:wptravelenginetripblocks/reviews-count /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->