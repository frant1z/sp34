<?php
/**
 * Template Helper Class.
 *
 * @since 6.0.0
 */

namespace WPTravelEngine\Helpers;

/**
 * Template Helper Class.
 *
 * @since 6.0.0
 */
class TemplateHelper {

}
