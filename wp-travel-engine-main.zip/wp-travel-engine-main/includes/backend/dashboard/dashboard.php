<?php
/**
 * WTE Dashboard page content.
 *
 * @since
 */
wp_enqueue_script( 'wte-global' );
wp_enqueue_script( 'wp-travel-engine' );
wp_enqueue_style( 'wp-travel-engine_core_ui' );
wp_enqueue_style( 'wte-fpickr' );
wp_enqueue_script( 'wptravelengine-dashboard-analytics' );
?>
<div id="wptravelengine_analytics_dashboard"></div>
