<?php return array('dependencies' => array(), 'version' => 'b86c796f78616baa5717');
