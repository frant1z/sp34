<?php
/**
 * Single trip check availability template.
 *
 * @package tripzzy
 * @since   1.1.9
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use Tripzzy\Core\Helpers\Strings;
use Tripzzy\Core\Helpers\TripFeatures;
use Tripzzy\Core\Helpers\Trip;
use Tripzzy\Core\Helpers\Amount;

$strings  = Strings::get();
$labels   = $strings['labels'] ?? array();
$duration = Trip::get_duration( null, false );

$trip             = $args['trip'];
$price_per        = $trip->get_price_per();
$price_per_key    = $trip->price_per;
$packages         = $trip->packages();
$package          = $packages->get_package();
$categories       = $package ? $package->get_categories() : null;
$default_category = $trip->package_category();

?>
<div class="tripzzy-check-availability tripzzy-stiky-box" id="tripzzy-check-availability">
	<div class="tripzzy-check-availability-content">
		<div class="tripzzy-check-availability-top">
			<div class="tripzzy-booking-top-area">
				<div class="tripzzy-duration">
					<span class="tripzzy-duration-label"><?php echo esc_html( $labels['duration'] ?? '' ); ?></span>
					<strong><?php printf( '%s %s', esc_html( $duration['duration'][0] ), esc_html( $duration['duration_unit'][0] ) ); ?></strong>
				</div>
				<div class="tripzzy-trip-code">
					<span><?php echo esc_html( $labels['trip_code'] ?? '' ); ?></span> : <code><?php echo esc_html( Trip::get_code() ); ?></code>
				</div>
			</div>
			<div class="tripzzy-booking-price-area tripzzy-price-per-<?php echo esc_attr( $price_per_key ); ?>">
				<?php
				if ( is_array( $categories ) && count( $categories ) > 0 ) {
					?>
					<div class="tripzzy-price-item-wrapper">
						<?php
						foreach ( $categories as $category ) {
							?>
							<div class="tripzzy-price-item">
								<span class="tripzzy-price-label">
								<?php echo esc_html( $category->get_title() ); ?>
								<?php if ( $category->has_sale() && $category->get_sale_percent() > 0 ) : ?>
										<span class="tripzzy-discount">-<?php echo esc_html( $category->get_sale_percent() ); ?>%</span>
									<?php endif; ?>
								</span>
								<?php if ( 'person' === $price_per_key ) : ?>
									<div class="tripzzy-price">
										<span class="tripzzy-price-from-text">
											<?php echo esc_html( $labels['from'] ?? '' ); ?>
											<?php if ( $category->has_sale() ) : ?>
												<del class="tripzzy-striked-price"><?php echo esc_html( Amount::display( $category->get_regular_price() ) ); ?></del>
											<?php endif; ?>
										</span>
										<span>
											<span class="tripzzy-booking-price"><?php echo esc_html( Amount::display( $category->get_price() ) ); ?></span> / <?php echo esc_html( $price_per ); ?>
										</span>
									</div>
								<?php endif; ?>
							</div>
							<?php
						}
						?>
					</div>
					<?php if ( 'group' === $price_per_key ) : ?>
						<div class="tripzzy-price">
							<span class="tripzzy-price-from-text">
								<?php echo esc_html( $labels['from'] ?? '' ); ?>
								<?php if ( $default_category->has_sale() ) : ?>
									<del class="tripzzy-striked-price"><?php echo esc_html( Amount::display( $default_category->get_regular_price() ) ); ?></del>
								<?php endif; ?>
							</span>
							<span>
								<span class="tripzzy-booking-price"><?php echo esc_html( Amount::display( $default_category->get_price() ) ); ?> </span> / <?php echo esc_html( $price_per ); ?>
							</span>
						</div>
						<?php
					endif;
				}
				?>
			</div>
			<?php TripFeatures::render( get_the_ID() ); ?>
		</div>
		<div class="tripzzy-booking-actions">
			<div class="tripzzy-button-group vertical">
				<a href='#tripzzy-availability-section' class='tz-btn tz-btn-solid' data-tripzzy-smooth-scroll><?php echo esc_html( $labels['check_availability'] ?? '' ); ?></a>
				<button data-tripzzy-drawer-trigger aria-controls="tripzzy-enquiry-form-wrapper" aria-expanded="false" type="button" id="tripzzy-enquiry-button" class='tz-btn tz-btn-outline'><?php echo esc_html( $labels['make_enquiry'] ?? '' ); ?></button>
			</div>
		</div>
	</div>
</div>