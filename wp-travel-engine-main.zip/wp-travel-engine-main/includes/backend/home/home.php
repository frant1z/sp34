<?php
/**
 * WTE Home page content.
 *
 * @since 5.6.0
 */

wp_enqueue_script( 'wte-global' );
wp_enqueue_script( 'wp-travel-engine' );
wp_enqueue_style( 'wp-travel-engine_core_ui' );
wp_enqueue_script( 'wptravelengine-dashboard' );
?>
<div id="wptravelengine_dashboard"></div>
